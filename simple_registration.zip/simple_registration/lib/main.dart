import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dart:async';
import "package:async/async.dart";
import 'package:path/path.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:flutter/widgets.dart';


void main() => runApp( MyApp());


String username='';


class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter App with MYSQL',
      home: new MyHomePage(),

    );
  }
}


class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}


class _MyHomePageState extends State<MyHomePage> {

  ImagePicker picker = ImagePicker();
  XFile image;
  File image1;

  TextEditingController Firstname=new TextEditingController();
  TextEditingController Lastname=new TextEditingController();
  TextEditingController Email=new TextEditingController();
  TextEditingController DOB=new TextEditingController();
  TextEditingController Occupation=new TextEditingController();


  @override
  void dispose() {
    Firstname.dispose();
    Lastname.dispose();
    Email.dispose();
    DOB.dispose();
    Occupation.dispose();

    super.dispose();
  }


  Future sendEmail(String Firstname, String email) async {
    final serviceId = 'service_oym640b';
    final templateId = 'template_qwqcyho';
    final userId = 'YKw9PU4Jm98YQtmFu';
    final url = Uri.parse("https://api.emailjs.com/api/v1.0/email/send");
    final response = await http.post(
      url,
      headers: {
        'origin': 'http://localhost',
        'Content-Type':'application/json',
      },
      body: json.encode({
       'service_id': serviceId,
        'template_id': templateId,
        'user_id': userId,
        'template_params': {
         'recipient':email,
          "Firstname": Firstname,
        }
      }),
    );
    print(response.body);
  }

  Future registerUser(File imageFile) async{
    var stream= new http.ByteStream(DelegatingStream.typed(imageFile.openRead()));
    var length= await imageFile.length();
    var uri = Uri.parse("http://192.168.56.1/insertdata.php");

    var request = new http.MultipartRequest("POST", uri);

    var multipartFile = new http.MultipartFile("image", stream, length, filename: basename(imageFile.path));

    request.files.add(multipartFile);
    request.fields['Firstname'] = Firstname.text;
    request.fields['Lastname'] = Lastname.text;
    request.fields['Email'] = Email.text;
    request.fields['DOB'] = DOB.text;
    request.fields['Occupation'] = Occupation.text;

    var respond = await request.send();
    if(respond.statusCode==200){
      print("User Successfully registered");
    }else{
      print("Upload Failed");
    }
  }


  Widget build(BuildContext) {
    return Scaffold(backgroundColor: Color(0xff000725),
      body: Form(
        //key: _formKey,
        child: ListView(
          children: <Widget>[
            Container(
              width: double.infinity,
              height: 180,
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    SizedBox(height: 50,),
                    Text("Registration Page",
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold,
                          fontSize: 25),
                    ),
                    Text("Kindly fill out the registration form below",
                      style: TextStyle(color: Colors.white),)
                  ],
                ),
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(150)
                ),
                color: Color(0xffff2fc3),),
            ),

          Container(
              padding: EdgeInsets.only(top:20, left:20, right:20),
              alignment: Alignment.topCenter,
              child: Column(
                children: [

                  ElevatedButton(
                      onPressed: () async {
                        image = await picker.pickImage(source: ImageSource.gallery);

                        setState(() {
                          image1 = File(image.path);
                          //update UI
                        });
                      },
                      child: Text("Add Profile Picture")
                  ),

                  image == null?Container():
                  Image.file(File(image.path))

                ],)
          ),



            Theme(
              data: ThemeData(
                  hintColor: Colors.blue
              ),
              child: Padding(
                padding: EdgeInsets.only(top: 50, right: 20, left: 20),
                child: TextFormField(
                  controller: Firstname,
                  validator: (value){
                    if(value.isEmpty){
                      return "Please enter your Firstname";
                    }
                    return null;
                  },
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                      labelText: "Firstname",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      ),
                      disabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      ),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      ),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      )
                  ),
                ),
              ),
            ),

            Theme(
              data: ThemeData(
                  hintColor: Colors.blue
              ),
              child: Padding(
                padding: EdgeInsets.only(top: 50, right: 20, left: 20),
                child: TextFormField(
                  controller: Lastname,
                  validator: (value){
                    if(value.isEmpty){
                      return "Please enter your Lastname";
                    }
                    return null;
                  },
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                      labelText: "Lastname",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      ),
                      disabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      ),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      ),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      )
                  ),
                ),
              ),
            ),

            Theme(
              data: ThemeData(
                  hintColor: Colors.blue
              ),
              child: Padding(
                padding: EdgeInsets.only(top: 50, right: 20, left: 20),
                child: TextFormField(
                  controller: Email,
                  validator: (value){
                    if(value.isEmpty){
                      return "Please enter your Email Address";
                    }
                    return null;
                  },
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                      labelText: "Email Address",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      ),
                      disabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      ),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      ),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      )
                  ),
                ),
              ),
            ),

            Theme(
              data: ThemeData(
                  hintColor: Colors.blue
              ),
              child: Padding(
                padding: EdgeInsets.only(top: 50, right: 20, left: 20),
                child: TextFormField(
                  controller: DOB,
                  validator: (value){
                    if(value.isEmpty){
                      return "Please enter your date of birth";
                    }
                    return null;
                  },
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                      labelText: "Date of Birth",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      ),
                      disabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      ),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      ),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      )
                  ),
                ),
              ),
            ),

            Theme(
              data: ThemeData(
                  hintColor: Colors.blue
              ),
              child: Padding(
                padding: EdgeInsets.only(top: 50, right: 20, left: 20),
                child: TextFormField(
                  controller: Occupation,
                  validator: (value){
                    if(value.isEmpty){
                      return "Please enter your Occupation";
                    }
                    return null;
                  },
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                      labelText: "Occupation",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      ),
                      disabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      ),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      ),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide(
                              color: Color(0xffff2fc3), width: 1)
                      )
                  ),
                ),
              ),
            ),

            SizedBox(height: 20,),
            Padding(
                padding: EdgeInsets.only(left: 20, right: 20),
                child: RaisedButton(
                  onPressed: () { registerUser(image1);
                  sendEmail(Firstname.text,Email.text);
                  },
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  color: Color(0xffff2fc3),
                  child: Text("Register", style: TextStyle(color: Colors.blue,
                      fontWeight: FontWeight.bold, fontSize: 20),),
                  padding: EdgeInsets.all(10),

                )
            ),

          ],
    ),
        )
    );
  }
}
